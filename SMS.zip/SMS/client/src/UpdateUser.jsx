import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios'

function UpdateUser() {
    const [id, setId]= useState()
    const [name, setName]= useState()
    const [email, setEmail]= useState()
    const [age, setAge]= useState()
    const [Class, setClass]= useState()
    const [year, setYear]= useState()
    const [address, setAddress]= useState()
    const navigate =  useNavigate()

    useEffect(()=> {
       axios.get('http://localhost:3001/getUser/'+id)
       .then(result => {console.log(result)
           setId(result.data.id)
           setName(result.data.name)
           setEmail(result.data.email)
           setAge(result.data.age)
           setClass(result.data.Class)
           setYear(result.data.year)
           setAddress(result.data.address)
           })
       .catch(err => console.log(err))
    }, [])
     
    const Update = (e) => {
        e.preventDefault()
        axios.put("http://localhost:3001/createUser/", {id,name,email,age,Class,year,address})
        .then(result=> {
            console.log(result)
            navigate('/')
        })        
        .catch(err => console.log(err))
    }

  return (
    <div className='d-flex vh-100 bg-primary justify-content-center align-items-center'>
      <div className='w-50 bg-white rounded p-3'>
        <form onSubmit={Update}>
            <h2>Update Student</h2>
            <div className ='mb-2'>
                <label htmlFor ="">ID</label>
                <input type = "text" placeholder='Enter Id' className='form-control'
                value={id}
                onChange={(e) => setId(e.target.value)}
                />
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Name</label>
                <input type = "text" placeholder='Enter Name' className='form-control'
                value={name}
                onChange={(e) => setName(e.target.value)}
                />
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Email</label>
                <input type = "Email" placeholder='Enter Email' className='form-control'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                />
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Age</label>
                <input type = "text" placeholder='Enter Age' className='form-control'
                value={age}
                onChange={(e) => setAge(e.target.value)}/>
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Class</label>
                <input type = "text" placeholder='Enter Class' className='form-control'
                value={Class}
                onChange={(e) => setClass(e.target.value)}/>
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Year</label>
                <input type = "text" placeholder='Enter Year' className='form-control'
                value={year}
                onChange={(e) => setYear(e.target.value)}/>
            </div>
            <div className ='mb-2'>
                <label htmlFor ="">Address</label>
                <input type = "text" placeholder='Enter Address' className='form-control'
                value={address}
                onChange={(e) => setAddress(e.target.value)}/>
            </div>
            <button className='btn btn-success'>Update</button>
        </form>
      </div>
    </div>
  )
}

export default UpdateUser