const mongoose = require('mongoose')

const UserShema = new mongoose.Schema({
    id: Number,
    name: String,
    email: String,
    age: Number,
    class: Number,
    year: Number,
    address: String
})

const UserModel = mongoose.model("users",UserShema)
module.exports = UserModel